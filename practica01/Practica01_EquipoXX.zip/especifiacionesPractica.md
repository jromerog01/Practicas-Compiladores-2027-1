---
universidad: Universidad Nacional Autónoma de México
facultad: Facultad de Ciencias
materia: Compiladores
semestre: 2027-1
profesora: L. en C.C. Yessica Janeth Pablo Martínez
ayudante_laboratorio: Pedro Yamil Salazar González
---

<div align="center">

# Universidad Nacional Autónoma de México

## Facultad de Ciencias

# Compiladores

**2027-1**

---

|                            |                                        |
| -------------------------: | :------------------------------------- |
|              **Profesora:** | L. en C.C. Yessica Janeth Pablo Martínez |
| **Ayudante de Laboratorio:** | Pedro Yamil Salazar González           |

---

# Práctica 1

*Semestre 2027-1*

</div>

---

## 1. Introducción

Un compilador transforma un programa escrito en un lenguaje fuente en una representación equivalente que pueda ser procesada o ejecutada por una computadora. Para realizar esta tarea, el proceso de compilación se divide en distintas etapas, cada una encargada de analizar o transformar un aspecto particular del programa.

La primera de estas etapas es el **análisis léxico**.

El analizador léxico, también denominado *lexer* o *scanner*, recibe como entrada una secuencia de caracteres y la transforma en una secuencia de unidades léxicas denominadas **tokens**.

Por ejemplo, considere el siguiente fragmento de código:

```c
int contador = 10;
```

Desde el punto de vista del analizador léxico, este código puede representarse mediante la siguiente secuencia de tokens:

```
INT         int
IDENTIFIER  contador
ASSIGN      =
INTEGER     10
SEMICOLON   ;
```

Cada token representa una categoría de elementos válidos dentro del lenguaje.

Durante esta práctica se construirá la infraestructura inicial del analizador léxico de **MiniC**, el lenguaje que será utilizado durante el curso para desarrollar incrementalmente las distintas etapas de un compilador.

La implementación realizada en esta práctica será extendida en las siguientes entregas, por lo que es importante mantener una organización modular, clara y documentada del código fuente.

## 2. Objetivo general

Diseñar e implementar la infraestructura básica del analizador léxico del lenguaje MiniC, permitiendo la representación de tokens, la lectura de archivos fuente y el reconocimiento de los primeros componentes léxicos del lenguaje.

## 3. Objetivos específicos

Al finalizar esta práctica, el estudiante será capaz de:

- comprender la función del analizador léxico dentro de un compilador;
- distinguir entre los conceptos de lexema, token, categoría léxica y patrón;
- representar las categorías léxicas mediante tipos enumerados;
- diseñar una estructura de datos para almacenar la información asociada a un token;
- leer y procesar archivos de código fuente;
- mantener la posición actual dentro del archivo mediante números de línea y columna;
- ignorar correctamente los caracteres de espacio en blanco;
- reconocer tokens formados por un único carácter;
- reconocer números enteros formados por uno o más dígitos;
- reconocer caracteres que no pertenezcan al subconjunto léxico implementado, generar un token `ERROR` con su posición y continuar el análisis desde el carácter siguiente;
- detectar el final del archivo fuente;
- organizar el código utilizando una arquitectura modular;
- utilizar un `Makefile` para automatizar el proceso de compilación.

## 4. Antecedentes

### 4.1. Lexemas y tokens

Un **lexema** es una secuencia concreta de caracteres presente en el código fuente.
Un **token** representa la categoría léxica a la que pertenece dicho lexema.

Por ejemplo:

| Lexema | Token       | Patrón   |
| ------ | ----------- | -------- |
| `10`   | `INTEGER`   | `[0-9]+` |
| `+`    | `PLUS`      | `+`      |
| `=`    | `ASSIGN`    | `=`      |
| `;`    | `SEMICOLON` | `;`      |

El analizador léxico deberá recorrer el archivo fuente de izquierda a derecha y producir los tokens correspondientes.

Por ejemplo, para el siguiente código:

```c
10 + 20;
```

el analizador deberá producir:

```
1:0 INTEGER 10
1:3 PLUS +
1:5 INTEGER 20
1:7 SEMICOLON ;
1:8 TOKEN_EOF
```

## 5. Descripción de la práctica

En esta práctica se desarrollará la infraestructura inicial del analizador léxico de MiniC.

El programa deberá realizar el siguiente proceso:

```
Archivo fuente
      |
      v
Lectura del archivo
      |
      v
Análisis de caracteres
      |
      v
Reconocimiento léxico básico
      |
      v
    Token
```

La implementación deberá permitir:

1. recibir la ruta de un archivo fuente desde la línea de comandos;
2. abrir y leer el archivo;
3. recorrer sus caracteres de izquierda a derecha;
4. mantener la línea y columna actuales;
5. ignorar los espacios en blanco;
6. reconocer símbolos simples;
7. reconocer números enteros sin signo;
8. generar un token `ERROR` por cada carácter no reconocido y continuar el análisis;
9. generar un token `TOKEN_EOF` al finalizar el archivo;
10. mostrar los tokens reconocidos en el formato establecido.

## 6. Especificación de MiniC

MiniC será el lenguaje utilizado durante el curso para construir incrementalmente un compilador.

La especificación completa del lenguaje será proporcionada en el classroom, en la sección de **Prácticas**, y deberá ser respetada durante todas las prácticas.

En esta práctica únicamente se implementará un subconjunto de los elementos léxicos de MiniC.

### 6.1. Tokens requeridos

El sistema de tokens deberá contemplar, como mínimo, las siguientes categorías:

```c
typedef enum {
    TOKEN_EOF,
    ERROR,
    IDENTIFIER,
    INTEGER,
    INT,
    BOOL,
    IF,
    ELSE,
    WHILE,
    PRINT,
    TRUE,
    FALSE,
    PLUS,
    MINUS,
    STAR,
    SLASH,
    ASSIGN,
    EQUAL,
    NOT_EQUAL,
    LESS,
    LESS_EQUAL,
    GREATER,
    GREATER_EQUAL,
    AND,
    OR,
    LPAREN,
    RPAREN,
    LBRACE,
    RBRACE,
    SEMICOLON
} TokenType;
```

> Aunque todas estas categorías deberán estar definidas desde esta práctica, **no todas serán reconocidas todavía** por el analizador léxico.

En esta entrega únicamente deberá implementarse el reconocimiento de:

- números enteros mediante el token `INTEGER`;
- operadores aritméticos de un carácter: `PLUS`, `MINUS`, `STAR` y `SLASH`;
- operador de asignación `ASSIGN`;
- operadores relacionales de un carácter: `LESS` y `GREATER`;
- los delimitadores: `LPAREN`, `RPAREN`, `LBRACE`, `RBRACE` y `SEMICOLON`;
- caracteres no reconocidos mediante `ERROR`;
- el final del archivo mediante `TOKEN_EOF`.

El resto de las categorías se reconocerá en la **Práctica 2**.

## 7. Representación de tokens

Cada token deberá almacenar, como mínimo:

- su categoría léxica;
- el lexema reconocido;
- la línea donde comienza;
- la columna donde comienza.

Se recomienda utilizar una estructura similar a la siguiente:

```c
typedef struct {
    TokenType type;
    char *lexeme;
    size_t line;
    size_t column;
} Token;
```

La implementación deberá considerar correctamente la administración de la memoria utilizada para almacenar los lexemas.

## 8. Requerimientos funcionales

### 8.1. Lectura del archivo fuente

El programa deberá recibir la ruta de un archivo fuente mediante los argumentos de la línea de comandos.

Ejemplo:

```bash
./minic programa.mc
```

El programa deberá validar, como mínimo:

- que se haya proporcionado un archivo;
- que el archivo pueda abrirse correctamente.

En caso contrario, deberá mostrarse un mensaje de error apropiado.

### 8.2. Seguimiento de línea y columna

El analizador deberá mantener en todo momento la posición actual dentro del archivo fuente.

Las líneas se numerarán a partir de **1** y las columnas a partir de **0**. Por lo tanto, la posición inicial del archivo será:

```
1:0
```

Cada token deberá almacenar la posición de su primer carácter. La posición se actualizará de acuerdo con las siguientes reglas:

- cualquier carácter ordinario incrementará la columna en uno;
- un espacio incrementará la columna en uno;
- un tabulador (`\t`) incrementará la columna en uno;
- un salto de línea (`\n`) incrementará la línea en uno y restablecerá la columna a cero;
- la secuencia `\r\n` se tratará como un único salto de línea;
- un retorno de carro aislado (`\r`) también se tratará como un salto de línea;
- `TOKEN_EOF` utilizará la posición inmediatamente posterior al último carácter procesado, después de ignorar cualquier espacio en blanco final.

Por ejemplo:

```c
10 + 20;
```

deberá producir:

```
1:0 INTEGER 10
1:3 PLUS +
1:5 INTEGER 20
1:7 SEMICOLON ;
1:8 TOKEN_EOF
```

Además un **archivo vacío** deberá producir:

```
1:0 TOKEN_EOF
```

Para un archivo que contenga `10;` **sin salto de línea final**:

```
1:0 INTEGER 10
1:2 SEMICOLON ;
1:3 TOKEN_EOF
```

Para un archivo que contenga `10;` **seguido de un salto de línea**:

```
1:0 INTEGER 10
1:2 SEMICOLON ;
2:0 TOKEN_EOF
```

### 8.3. Manejo de espacios en blanco

El analizador léxico deberá ignorar los siguientes caracteres:

- espacio;
- tabulador;
- salto de línea;
- retorno de carro.

Es decir:

```c
' '
'\t'
'\n'
'\r'
```

Estos caracteres **no deberán generar tokens**.
Sin embargo, deberán actualizar correctamente la línea y columna actuales.

### 8.4. Reconocimiento de símbolos simples

El analizador deberá reconocer los siguientes símbolos:

| Lexema | Token       |
| ------ | ----------- |
| `+`    | `PLUS`      |
| `-`    | `MINUS`     |
| `*`    | `STAR`      |
| `/`    | `SLASH`     |
| `=`    | `ASSIGN`    |
| `<`    | `LESS`      |
| `>`    | `GREATER`   |
| `(`    | `LPAREN`    |
| `)`    | `RPAREN`    |
| `{`    | `LBRACE`    |
| `}`    | `RBRACE`    |
| `;`    | `SEMICOLON` |

Todos estos tokens consumen exactamente un carácter del archivo fuente.

### 8.5. Reconocimiento de números enteros

El analizador deberá reconocer números enteros sin signo formados por uno o más dígitos.

El patrón correspondiente es:

```
[0-9]+
```

Ejemplos válidos:

```
0
5
10
123
2026
```

El analizador deberá consumir todos los dígitos consecutivos como un único token.

Por ejemplo:

```c
123 + 45;
```

deberá producir:

```
1:0 INTEGER 123
1:4 PLUS +
1:6 INTEGER 45
1:8 SEMICOLON ;
1:9 TOKEN_EOF
```

El signo de un número negativo **no forma parte** del token `INTEGER`.

Por ejemplo:

```c
-10;
```

deberá reconocerse como:

```
1:0 MINUS -
1:1 INTEGER 10
1:3 SEMICOLON ;
1:4 TOKEN_EOF
```

### 8.6. Final del archivo

Cuando no existan más caracteres por procesar, el analizador deberá generar un token:

```
TOKEN_EOF
```

Este token indicará que el análisis del archivo fuente ha terminado.

La representación de `TOKEN_EOF` deberá seguir el formato definido en la **sección 9**.

### 8.7. Caracteres no reconocidos

Debido a que el manejo completo de errores léxicos será implementado en la práctica 2, en esta entrega los caracteres que no pertenezcan al subconjunto reconocido deberán producir un:

```
ERROR
```

El token deberá conservar:

- el carácter problemático;
- la línea;
- la columna.

Por ejemplo, para:

```c
10 @ 20;
```

el carácter `@` deberá producir un `ERROR`.

El analizador deberá continuar procesando el resto del archivo después de encontrar dicho token.

## 9. Formato de salida

Los tokens deberán escribirse en la salida estándar (`stdout`) en el mismo orden en que aparecen en el archivo fuente. Cada token distinto de `TOKEN_EOF` deberá ocupar exactamente una línea con el siguiente formato:

```
línea:columna TIPO_TOKEN lexema
```

Entre los tres campos deberá existir exactamente **un espacio ASCII**. No deberán agregarse etiquetas, tabuladores, líneas vacías ni mensajes adicionales. El token `TOKEN_EOF` no tendrá lexema y deberá imprimirse con el siguiente formato:

```
línea:columna TOKEN_EOF
```

El token `ERROR` se imprimirá como cualquier otro token y conservará el carácter problemático como lexema:

```
línea:columna ERROR carácter
```

Los diagnósticos relacionados con los argumentos incorrectos o archivos que no puedan abrirse deberán escribirse en la salida de error (`stderr`) y no deberán mezclarse con la secuencia de tokens.

Para un archivo que contenga exactamente:

```c
10 + 20;
```

sin un salto de línea al final, la salida deberá ser:

```
1:0 INTEGER 10
1:3 PLUS +
1:5 INTEGER 20
1:7 SEMICOLON ;
1:8 TOKEN_EOF
```

Para la entrada:

```c
10 @ 20;
```

la salida deberá ser:

```
1:0 INTEGER 10
1:3 ERROR @
1:5 INTEGER 20
1:7 SEMICOLON ;
1:8 TOKEN_EOF
```

## 10. Estructura del proyecto

El proyecto deberá respetar, como mínimo, la siguiente organización:

```
.
|-- include/
|   `-- lexer/
|       |-- lexer.h
|       `-- token.h
|
|-- src/
|   |-- lexer/
|   |   |-- lexer.c
|   |   `-- token.c
|   |
|   `-- main.c
|
|-- tests/
|
|-- Makefile
|-- README.md
`-- CHANGELOG.md
```

> **No se permitirá implementar todo el programa dentro de `main.c`.**

El archivo `main.c` deberá limitarse principalmente a:

1. validar los argumentos;
2. inicializar los componentes necesarios;
3. solicitar los tokens al analizador léxico;
4. mostrar los resultados;
5. liberar los recursos utilizados.

La lógica correspondiente al análisis léxico deberá encontrarse en los módulos destinados para ello.

## 11. Compilación

El proyecto deberá incluir un `Makefile`.

Como mínimo, deberá ser posible compilar el proyecto mediante:

```bash
make
```

Después de la compilación deberá generarse un ejecutable llamado:

```
minic
```

El programa deberá poder ejecutarse mediante:

```bash
./minic programa.mc
```

El `Makefile` deberá incluir también una regla para eliminar los archivos generados durante la compilación:

```bash
make clean
```

No deberán entregarse archivos binarios, archivos objeto ni otros archivos generados automáticamente durante la compilación.

## 12. Pruebas

El proyecto deberá incluir pruebas que permitan verificar el funcionamiento del analizador léxico.

Como mínimo, deberán probarse los siguientes casos:

- archivo vacío;
- archivo con únicamente espacios en blanco;
- un único token;
- todos los símbolos simples;
- un número de un dígito;
- un número de varios dígitos;
- varios tokens en una línea;
- tokens distribuidos en varias líneas;
- combinación de espacios y tabuladores;
- carácter no reconocido;
- varios caracteres no reconocidos;
- posición correcta de línea y columna;
- detección correcta del final del archivo.

Se proporcionará una batería de archivos `.mc` para verificar el funcionamiento básico de la implementación.

Adicionalmente, durante la evaluación podrán utilizarse casos de prueba privados.
La implementación no deberá depender únicamente de los ejemplos proporcionados.

## 13. Restricciones

Para esta práctica:

- el lenguaje de implementación deberá ser **C**;
- no deberán utilizarse generadores automáticos de analizadores léxicos;
- no deberán utilizarse herramientas como **Lex** o **Flex**;
- no deberán utilizarse bibliotecas externas para realizar el análisis léxico;
- no deberán modificarse las categorías léxicas establecidas en la especificación;
- no deberá implementarse todo el programa dentro de `main.c`;
- deberá respetarse la estructura mínima del proyecto;
- deberá utilizarse un `Makefile`;
- deberán seguirse los lineamientos generales de entrega de prácticas del curso.

## 14. Entregables

La entrega deberá incluir:

```
Práctica 1.
|
|-- Código fuente
|   |-- lectura del archivo
|   |-- sistema de tokens
|   |-- seguimiento de línea y columna
|   |-- manejo de espacios en blanco
|   |-- reconocimiento de símbolos simples
|   |-- reconocimiento de números enteros
|   |-- ERROR
|   `-- TOKEN_EOF
|
|-- Archivos de encabezado
|
|-- Pruebas
|
|-- Makefile
|
|-- README.md
|
|-- CHANGELOG.md
|
`-- Reporte
```

Todos los elementos deberán entregarse de acuerdo con los lineamientos generales establecidos para el curso.

## 15. Criterios de evaluación

La evaluación se realizará de acuerdo con los criterios generales establecidos para la entrega de prácticas, considerando los objetivos y requerimientos específicos de esta práctica.

La siguiente rúbrica describe los elementos considerados para la evaluación de la Práctica 1.

| Aspecto | Criterios específicos | Ponderación |
| ------- | --------------------- | ----------- |
| **Correctitud de la implementación** | Reconocimiento de símbolos simples y números enteros; manejo de espacios en blanco; seguimiento de línea y columna; generación de `ERROR` y `TOKEN_EOF`. | 40 % |
| **Diseño y calidad del código** | Sistema de tokens; modularidad; separación de responsabilidades; organización del código y administración correcta de memoria. | 20 % |
| **Documentación** | Cumplimiento de los lineamientos del reporte, `README.md` y `CHANGELOG.md`; claridad y registro adecuado de los cambios realizados. | 20 % |
| **Compilación y ejecución** | Compilación mediante el `Makefile`; generación del ejecutable `minic`; ejecución mediante la interfaz especificada y cumplimiento del formato de salida. | 20 % |
| **Total** | | **100 %** |

La evaluación considerará tanto el funcionamiento correcto del programa como la calidad de la implementación. Un programa que produzca la salida esperada, pero que no respete la estructura, modularidad, documentación o restricciones establecidas, podrá recibir penalizaciones de acuerdo con los lineamientos generales del curso.

## 16. Resultado esperado

Al finalizar esta práctica, se deberá contar con la primera versión funcional del analizador léxico de MiniC. El sistema construido deberá ser capaz de realizar el siguiente proceso:

```
Código fuente
      |
      v
Lectura del archivo
      |
      v
Seguimiento de posición
      |
      v
Reconocimiento léxico básico
      |
      |-- espacios en blanco
      |-- símbolos simples
      |-- números enteros
      |-- errores básicos
      `-- final del archivo
      |
      v
Secuencia de Tokens
```

Esta implementación constituirá la base para la **práctica 2**, en la que el analizador será extendido para reconocer identificadores, palabras reservadas, operadores compuestos, comentarios y realizar un manejo más completo de errores léxicos.

Por esta razón, el código desarrollado en esta entrega deberá considerarse como el inicio de un proyecto incremental y no como un programa independiente que será descartado al finalizar la práctica.

---

> *"I can only show you the door. You're the one that has to walk through it."*
> — Morpheus, *The Matrix*
